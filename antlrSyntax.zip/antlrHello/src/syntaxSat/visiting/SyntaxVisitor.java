package syntaxSat.visiting;

import syntaxSat.generated.SyntaxSatBaseVisitor;

public class SyntaxVisitor extends SyntaxSatBaseVisitor<Object> {

	
}
